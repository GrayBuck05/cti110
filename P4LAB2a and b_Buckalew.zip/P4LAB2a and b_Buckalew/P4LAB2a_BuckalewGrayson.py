import turtle             
turtle.forward(60)
turtle.left(90)
turtle.forward(60)
turtle.left(90)
turtle.forward(60)
turtle.left(90)
turtle.forward(60)
turtle.left(90)

              
import turtle
 
Grayson= turtle.Turtle()
 
Grayson.forward(105) 
 
Grayson.left(125)
Grayson.forward(105)
 
Grayson.left(125)
Grayson.forward(105)
 
turtle.done()
